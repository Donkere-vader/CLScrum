CL Scrum V1.5 [STABLE]

If you encounter any bugs please let me know.
E-mail: clsoftsolutions@gmail.com

[INSTALLATION]
Make sure that the .exe and the .ico files are in a normal directory (not still in the .zip) and then run the .exe.
When runned for the first time it will create a new directory called 'Boards', please don't touch this file if you 
don't know what you are doing.

It is necacerry for the program to run that the "clScumIcon.ico" file is in the same directory, 
without it the pogram will crash.